"""
Created on Sun Mar 23 10:00:32 2022

@author: rahul
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers.convolutional import Convolution2D
from keras.utils import np_utils
from sklearn.preprocessing import StandardScaler
from keras import backend as K
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings("ignore")

l1=0.45
l2=0.35
l3=0.20


def my_loss1(X1,s):
    def my_loss(y_true,y_pred):
        y3=K.argmax(y_true, axis=1)
        y_pred /=K.sum(y_pred, axis=1,keepdims=True)
        y4=tf.gather(y_pred,y3, axis=1)
        y21=tf.linalg.diag_part(y4)
        y21=tf.reshape(y21,[-1,1])
        epsilon =K.epsilon()
        y21=K.clip(y21, epsilon, 1. -epsilon)
        y22=tf.reshape(y21,[-1,1])
        student_loss=-(tf.math.log(y22))
        temperature=3
        trainee_prediction=trainee(X1)
        #trainee_prediction=trainee.predict(X_train)
        #print(teacher_prediction.shape)
        student_prediction=s
        #student_prediction=student_d.predict(X_train)
        #print(student_prediction.shape)
        a=tf.nn.softmax(trainee_prediction/temperature, axis=1)
        b=tf.nn.softmax(student_prediction/temperature, axis=1)
        attension_loss=(a-b)/len(X1)
        #print(distillation_loss)
        al=K.mean(attension_loss)
        cl=K.mean(student_loss)
        #distillation
        teacher_prediction=large_teacher(X1)
        #teacher_prediction=teacher.predict(X_train)
        c=tf.nn.softmax(teacher_prediction/temperature, axis=1)
        distillation_loss=(c-b)/len(X1)
        dl=K.mean(distillation_loss)
        loss1 = l1* cl + l2* dl + l3*al
        return loss1
    return my_loss 


def my_loss2(X1,t,s):
    def my_loss(y_true,y_pred):
        y3=K.argmax(y_true, axis=1)
        y_pred /=K.sum(y_pred, axis=1,keepdims=True)
        y4=tf.gather(y_pred,y3, axis=1)
        y21=tf.linalg.diag_part(y4)
        y21=tf.reshape(y21,[-1,1])
        epsilon =K.epsilon()
        y21=K.clip(y21, epsilon, 1. -epsilon)
        y22=tf.reshape(y21,[-1,1])
        student_loss=-(tf.math.log(y22))
        temperature=3
        alpha=0.2
        a=tf.nn.softmax(t/temperature, axis=1)
        b=tf.nn.softmax(s/temperature, axis=1)
        distillation_loss=(a-b)
        dl=K.mean(distillation_loss)/len(X1)
        cl=K.mean(student_loss)
        loss1 = alpha * cl + (1 - alpha) * dl
        return loss1
    return my_loss 


# creating teacher.............................................................
def large_teacher():
    model = Sequential()
    model.add(Convolution2D(64, 1, 1, input_shape=(28,28,1), activation= 'relu' ))
    model.add(Convolution2D(32, 1, 1, activation= 'relu' ))
    model.add(Convolution2D(32, 1, 1, activation= 'relu' ))
    model.add(Convolution2D(16, 1, 1, activation= 'relu' ))
    model.add(Flatten())
    model.add(Dense(1024, activation= 'relu', name ="e1"  ))
    model.add(Dense(10, activation= 'softmax' , name ="teacher" ))
    model.compile(loss= 'categorical_crossentropy' , optimizer= 'adam' , metrics=[ 'accuracy' ])
    return model

large_teacher = large_teacher()
trainee=large_teacher
i=1
j=1
def trainc(X,y,teacher):
    teacher=teacher
    X=X
    y=y
    X1, X2, y1, y2 = train_test_split(X, y, test_size=0.2, random_state=42)
    #large_teacher=large_teacher()
    t=large_teacher.predict(X1)
    s=teacher.predict(X1)
    large_teacher.compile(loss=my_loss2(X1,t, s) , optimizer= 'adam' , metrics=[ 'accuracy' ])
    large_teacher.fit(X1, y1, epochs=15, batch_size=200, verbose=0)
    scores = large_teacher.evaluate(X2, y2, verbose=0)
    #print("Insufficient--Distilled student loss: %.2f%%" % (scores[0]))
    print("Colossal--Distilled participant accuracy",scores[1]*100) 
    send_model=retraining(X, y, teacher, large_teacher)
    return send_model

def retraining(X,y, teacher, large_teacher):
    X=X
    y=y
    X1, X2, y1, y2 = train_test_split(X, y, test_size=0.2, random_state=42)
    s=teacher.predict(X1)
    trainee.compile(loss='categorical_crossentropy', optimizer= 'adam' , metrics=[ 'accuracy' ])
    teacher.compile(loss=my_loss1(X1,s) , optimizer= 'adam' , metrics=[ 'accuracy' ])
    #trainee.compile(loss='categorical_crossentropy', optimizer= 'adam' , metrics=[ 'accuracy' ])
    for i,j in zip(range(1,15), range(1,15)):
            if j < 10:
                trainee.fit(X1, y1, epochs=1, batch_size=200, verbose=0)
                a=j
            #print("halting epochs",str(a))
            teacher.fit(X1, y1, epochs=1, batch_size=200, verbose=0)
            #print("local epoch",str(i))
    scores = teacher.evaluate(X2, y2, verbose=0)
    #acc=(100-scores[1]*100)
    print("Colossal--Distilled  accuracy",scores[1]*100)
    print("local epoch",str(i))
    print("halting epochs",str(a))
    return teacher



