#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 16 10:52:14 2022

@author: ubiquitous
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 13 10:00:32 2022

@author: rahul
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers.convolutional import Convolution2D
from keras.utils import np_utils
from sklearn.preprocessing import StandardScaler
from keras import backend as K
import warnings
from sklearn.model_selection import train_test_split
warnings.filterwarnings("ignore")


def my_loss1(X1,t,s):
    def my_loss(y_true,y_pred):
        y3=K.argmax(y_true, axis=1)
        y_pred /=K.sum(y_pred, axis=1,keepdims=True)
        y4=tf.gather(y_pred,y3, axis=1)
        y21=tf.linalg.diag_part(y4)
        y21=tf.reshape(y21,[-1,1])
        epsilon =K.epsilon()
        y21=K.clip(y21, epsilon, 1. -epsilon)
        y22=tf.reshape(y21,[-1,1])
        student_loss=-(tf.math.log(y22))
        temperature=3
        alpha=0.2
        a=tf.nn.softmax(t/temperature, axis=1)
        b=tf.nn.softmax(s/temperature, axis=1)
        distillation_loss=(a-b)
        dl=K.mean(distillation_loss)/len(X1)
        cl=K.mean(student_loss)
        loss1 = alpha * cl + (1 - alpha) * dl
        return loss1
    return my_loss 


def my_loss2(X1,t,s):
    def my_loss(y_true,y_pred):
        y3=K.argmax(y_true, axis=1)
        y_pred /=K.sum(y_pred, axis=1,keepdims=True)
        y4=tf.gather(y_pred,y3, axis=1)
        y21=tf.linalg.diag_part(y4)
        y21=tf.reshape(y21,[-1,1])
        epsilon =K.epsilon()
        y21=K.clip(y21, epsilon, 1. -epsilon)
        y22=tf.reshape(y21,[-1,1])
        student_loss=-(tf.math.log(y22))
        temperature=3
        alpha=0.2
        a=tf.nn.softmax(t/temperature, axis=1)
        b=tf.nn.softmax(s/temperature, axis=1)
        distillation_loss=(a-b)
        dl=K.mean(distillation_loss)/len(X1)
        cl=K.mean(student_loss)
        loss1 = alpha * cl + (1 - alpha) * dl
        return loss1
    return my_loss 

def student_d():
    model = Sequential()
    model.add(Convolution2D(8, 1, 1, input_shape=(28,28,1), activation= 'relu' ))
    model.add(Convolution2D(8, 1, 1, activation= 'relu' ))
    model.add(Flatten())
    model.add(Dense(8, activation= 'relu', name ="e"  ))
    model.add(Dense(10, activation= 'softmax', name ="s1" ))
    return model

#student_d=student_d()

def trainc(X,y,teacher):
    teacher=teacher
    X=X
    y=y
    X1, X2, y1, y2 = train_test_split(X, y, test_size=0.2, random_state=42)
    student=student_d()
    t=teacher.predict(X1)
    s=student.predict(X1)
    student.compile(loss=my_loss1(X1,t, s) , optimizer= 'adam' , metrics=[ 'accuracy' ])
    student.fit(X1, y1, epochs=3, batch_size=200, verbose=0)
    scores = student.evaluate(X2, y2, verbose=0)
    #print("Insufficient--Distilled student loss: %.2f%%" % (scores[0]))
    #print("Insufficient--Distilled student accuracy",scores[1]*100) 
    send_model=retraining(X, y, teacher, student)
    return send_model



def retraining(X,y, teacher, student):
    X=X
    y=y
    X1, X2, y1, y2 = train_test_split(X, y, test_size=0.2, random_state=42)
    t=teacher.predict(X1)
    s=student.predict(X1)
    teacher.compile(loss=my_loss2(X1,t, s) , optimizer= 'adam' , metrics=[ 'accuracy' ])
    teacher.fit(X1, y1, epochs=2, batch_size=200, verbose=0)
    scores = teacher.evaluate(X2, y2, verbose=0)
    #print("Insufficient--Distilled loss: %.2f%%" % (scores[0]))
    print("Insufficient--Distilled  accuracy",scores[1]*100) 
    return teacher
    