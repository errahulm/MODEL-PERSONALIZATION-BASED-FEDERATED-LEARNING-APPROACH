#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 14 16:56:26 2022

@author: ubiquitous
"""

####################...............Libraries
from tensorflow.keras.optimizers import Adam
from sklearn.metrics import accuracy_score
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers
import numpy as np
import pandas as pd
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Flatten
from keras.layers.convolutional import Convolution2D
from keras.utils import np_utils
from sklearn.preprocessing import StandardScaler
from keras import backend as K
from sklearn.model_selection import train_test_split
import insufficient as insf
import colossal as col
import warnings
warnings.filterwarnings("ignore")


###############..............dataset................


import tensorflow as tf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from os import listdir
from tensorflow.keras.preprocessing import sequence
import tensorflow as tfs
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Flatten
from tensorflow.keras.layers import LSTM

from tensorflow.keras.optimizers import Adam
from tensorflow.keras.models import load_model
from tensorflow.keras.callbacks import ModelCheckpoint

from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import Flatten
from tensorflow.keras.layers import Dropout
from sklearn.model_selection import train_test_split
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Flatten, Conv2D, MaxPooling2D,LeakyReLU
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import os
import cv2, random

height=28
width=28
depth=1

inputShape = (height, width, depth)

# Prepare the train and test dataset.
from tensorflow import keras
batch_size = 64
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()

# Normalize data
x_train = x_train.astype("float32") / 255.0
x_train = np.reshape(x_train, (-1, 28, 28, 1))

x_test = x_test.astype("float32") / 255.0
x_test = np.reshape(x_test, (-1, 28, 28, 1))

from  keras.utils import np_utils
y_train = np_utils.to_categorical(y_train)
y_test= np_utils.to_categorical(y_test)
# print(y_train[0])
# print(y_train.shape,y_test.shape)
# print(x_train.shape)
# print(y_train[0],x_train[0])

from sklearn.utils import shuffle
x_train, y_train= shuffle(x_train, y_train, random_state=0)
X=[]
Y=[]
j=0
for i in range(5):
  X.append(x_train[j:j+12000])
  Y.append(y_train[j:j+12000])
  j+=12000

X=np.array(X)
Y=np.array(Y)
trainX=X
trainy=Y
X_test=x_test
y_test=y_test
# print(X.shape,Y.shape)
#print(trainX.shape,trainy.shape)

################.....model...........................
class MODEL:
    @staticmethod
    def build():
            model = Sequential()
            model.add(Convolution2D(8, 1, 1, input_shape=(28,28,1), activation= 'relu' ))
            model.add(Convolution2D(8, 1, 1, activation= 'relu' ))
            model.add(Flatten())
            model.add(Dense(16, activation= 'relu', name ="e1"  ))
            model.add(Dense(10, activation= 'softmax' , name ="teacher" ))
            return model
        
class MODEL1:
    @staticmethod
    def build():
            model = Sequential()
            model.add(Convolution2D(8, 1, 1, input_shape=(28,28,1), activation= 'relu' ))
            model.add(Convolution2D(8, 1, 1, activation= 'relu' ))
            model.add(Flatten())
            model.add(Dense(16, activation= 'relu', name ="e1"  ))
            model.add(Dense(10, activation= 'softmax' , name ="teacher" ))
            return model  
        
class MODEL2:
    @staticmethod
    def build():
            model = Sequential()
            model.add(Convolution2D(8, 1, 1, input_shape=(28,28,1), activation= 'relu' ))
            model.add(Convolution2D(8, 1, 1, activation= 'relu' ))
            model.add(Flatten())
            model.add(Dense(16, activation= 'relu', name ="e1"  ))
            model.add(Dense(10, activation= 'softmax' , name ="teacher" ))
            return model     

class MODEL3:
    @staticmethod
    def build():
            model = Sequential()
            model.add(Convolution2D(8, 1, 1, input_shape=(28,28,1), activation= 'relu' ))
            model.add(Convolution2D(8, 1, 1, activation= 'relu' ))
            model.add(Flatten())
            model.add(Dense(16, activation= 'relu', name ="e1"  ))
            model.add(Dense(10, activation= 'softmax' , name ="teacher" ))
            return model        

def scale_model_weights(weight, scalar):
    '''function for scaling a models weights'''
    weight_final = []
    steps = len(weight)
    for i in range(steps):
        weight_final.append(scalar * weight[i])
    return weight_final

def test_model(X_test, Y_test,  model, comm_round):
    # print('comm_round: {} | global_acc: {:.3%} | global_loss: {}'.format(comm_round, acc, loss))
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
    scores=model.evaluate(X_test,y_test,verbose=0)
    acc=(scores[1]*100)
    #loss=scores[0]
    return acc

def sum_scaled_weights(scaled_weight_list):
    '''Return the sum of the listed scaled weights. The is equivalent to scaled avg of the weights'''
    avg_grad = list()
    #get the average grad accross all client gradients
    for grad_list_tuple in zip(*scaled_weight_list):
        layer_mean = tf.math.reduce_sum(grad_list_tuple, axis=0)
        avg_grad.append(layer_mean)
      
    return avg_grad


def adequate(ind):
    print(".............adequate resource participants........................")
    local = MODEL1()
    local_model=local.build()
    local_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    local_model.set_weights(global_weights)
    history=local_model.fit(trainX[ind],trainy[ind], epochs=10,verbose=0)#,validation_data=(x_test,y_test))
    print("Accuracy of client:"+str(ind)+" = ",history.history['accuracy'][0])
    scaling_factor=0.3 #1/no.ofclients
    aqu = scale_model_weights(local_model.get_weights(), scaling_factor)
    return aqu


def colossal(ind):
    print("..............colossal resource participants.......................")
    local = MODEL2()
    local_model=local.build()
    local_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    local_model.set_weights(global_weights)
    received_model=col.trainc(trainX[ind],trainy[ind],local_model)
    #history=local_model.fit(trainX[ind],trainy[ind], epochs=10,verbose=0)#,validation_data=(x_test,y_test))
    #print("Accuracy of client:"+str(ind)+" = ",history.history['accuracy'][0])
    scaling_factor=0.6 #1/no.ofclients
    col1 = scale_model_weights(received_model.get_weights(), scaling_factor)
    return col1

def insufficient1(ind):
    print("...............insufficient resource participants..................")
    local = MODEL3()
    local_model=local.build()
    local_model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
    local_model.set_weights(global_weights)
    received_model=insf.trainc(trainX[ind],trainy[ind], local_model)
    scaling_factor=0.1 
    insuff = scale_model_weights(received_model.get_weights(), scaling_factor)
    return insuff

#student_d=insf.student_d()
global1= MODEL()
global_model = global1.build()
lr = 0.001 
comms_round = 5
avg_grad = list()
adam = Adam(lr=lr, decay=lr / comms_round) 
#print(trainy[2].shape)

c0="suff"
c1=c3="col"
c2=c4="insuff"

for comm_round in range(10):
  print("comm_round:", str(comm_round+1))
  global_weights = global_model.get_weights()
  scaled_local_weight_list = list()
  index=list({0,1,2,3,4})
  ind=0
  for ind in range(3):
      if ind==0: 
          scaled_weights=adequate(ind)
          #print("move ahead")
      elif ind ==1:
          #print("move ahead")
          scaled_weights=colossal(ind)
          
      else:
           scaled_weights=insufficient1(ind)
      scaled_local_weight_list.append(scaled_weights)
      K.clear_session()
  global_weight= sum_scaled_weights(scaled_local_weight_list)
  global_model.set_weights(global_weight)
  global_acc = test_model(X_test,y_test, global_model, comm_round)
  print("____________next round____________")
  print("\n")
print(global_acc)




